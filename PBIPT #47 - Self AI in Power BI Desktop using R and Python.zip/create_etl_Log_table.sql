use[AdventureWorksDW2017];
DROP TABLE IF EXISTS dbo.[etl_Log]; 
CREATE TABLE dbo.[etl_Log] (
load_date DATETIME  DEFAULT (getdate()),
table_name VARCHAR(25),
num_of_records INT
)

select * from dbo.[etl_Log];


