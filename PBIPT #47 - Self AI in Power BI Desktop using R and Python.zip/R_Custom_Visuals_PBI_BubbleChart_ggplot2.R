# Input load. Please do not change #

#On your computer that R will look for files to 
#read and will write files if not given a full directory path
setwd("E:/R_Custom_Visuals_PBI_BubbleChart_ggplot2")

`dataset` = read.csv('Players_Baskets.csv', check.names = FALSE, encoding = "UTF-8", blank.lines.skip = FALSE);
# The following code to create a dataframe and remove duplicated rows is always executed and acts as a preamble for your script: 

# dataset <- data.frame(ID, Year, First_Name, Last_Name, Weight, Height, Baskets, League, Region)
# dataset <- unique(dataset)
# Paste or type your script code here:

# Easiest way to get dplyr and ggplot2  is to install\load the whole tidyverse:
# https://www.rdocumentation.org/packages/dplyr/versions/0.7.8 
# ggplot2 : create the visual
# dplyr  manipulation of  data passed to R from Power BI


# Create a dataframe and remove duplicated rows is always executed for Power Bi :

# dataset <- data.frame(ID, Year, First_Name, Last_Name, Weight, Height, Baskets, League, Region)
# dataset <- unique(dataset)


# Paste or type your script code here:

#tidyverse 
# https://www.tidyverse.org/
# A  collection of open source R libraries to clean,structure and visualize data.  

# Load the required packages
# ==========================
# Easiest way to get dplyr and ggplot2  is to install\load the whole tidyverse
# ggplot2 is data visualization part https://ggplot2.tidyverse.org/index.html
# dplyr :  manipulation of  data passed to R from Power BI

# Package ggrepel :  Automatically Position Non-Overlapping Text Labels with ggplot2 
# Package ggthemes : change the display of the non-data components of the visual

library(tidyverse)
library(ggrepel)
library(ggthemes)
head(dataset)


# Variables for checking Data 
# =========================================================
# Source_Columns : column names of the data frame passed to R from Power BI. 
# Names sorted in alphabetical order for comparison
Source_Columns<- sort(colnames(dataset)) 
#Source_Columns

#PowreBI_Columns :  names of required columns.
PowreBI_Columns <- c("Baskets","First_Name","Height","ID","Last_Name","League","Region","Weight","Year" )
#PowreBI_Columns

# all.equal() function with isTRUE()return TRUE when all.equal() returns TRUE
# and FALSE when all.equal() <> TRUE

Columns_Compare <- isTRUE(all.equal(Source_Columns, PowreBI_Columns))
#Columns_Compare

# unique() function to get a list of unique year from Year column.
Slicer_Year <- unique(dataset$Year)
#Slicer_Year

# Data Test
# 1. If  length of Slicer_Year vector is equal to one. 
# 2. if Columns_Compare var is TRUE
if(length(Slicer_Year) == 1 & Columns_Compare) {
  
  R_Visual_Data <-
    #  %>% Pipe an object forward into a function or call expression
    dataset %>%
    mutate(Name = paste0(substring(First_Name,1,1),". ", Last_Name))
    #dplyr, mutate() adds new variables functions of existing variables
  
  # Define  colors by  named character vectors
  # ===========================================
  # Use  color name or exadecimal for ggplot2 
  # exadecimal colors: www.hexcolortool.com/#010328

  RegionColors <- c("Asia"="#61b8ea", "Africa"="#2efcff", "America"="#efe339", "Europe"="#909292")
  LeagueColors <-  c("ABA"="#000000", "NBA"="#fd5412")
  
  # Define dynamically title of chart
  # ====================================
  Chart_Title <- paste("R Custom Visuals ggplot Bubble  for", Slicer_Year, sep = " ")
  
  p <- ggplot(
    # Create the visual data set
    R_Visual_Data, 
# Create chart with ggplot function
# ===================================================
# bubble chart with 6 dimensions: 
# x : weight
# y : height
# Size of the bubble : Baskets 
# Fill (inside color) : Region 
# color (border of the bubble) : League
# label : name 

# set  dimensions by aes() function in the ggplot() function 
    aes(
      x = Weight, y = Height, size = `Baskets`, 
      color = League, fill = Region, stroke = 2,
      # stroke argument control the size of the edge/border of point
      label = Name
    )
  ) +
  # Change the color of borders and fill of bubbles . 
  # ===============================================
  # scale_color_manual() : Change color of bubbles using predefined colors by LeagueColors named character vector. 
    scale_color_manual(values = LeagueColors) +
  # scale_fill_manual() : Change color of bubbles fill by RegionColor named character vectors  . 
    scale_fill_manual(values = RegionColors) +
    # 3 shapes can be used to create bubble charts 1,16, and 21. 
     # Only shape 21 can define border color and  fill
     # Aesthetic specifications : https://ggplot2.tidyverse.org/articles/ggplot2-specs.html
    geom_point(shape = 21) +
    # Add labels Visual
    # ===================
    # Getting started with ggrepel : https://cran.r-project.org/web/packages/ggrepel/vignettes/ggrepel.html
    # ggrepel provides geoms for ggplot2 to repel overlapping text labels: 
    # geom_text_repel() geom tries to prevent overlapping when it adds labels
    geom_text_repel(size = 5) +

    # Create the title
    # =================
    #  ggtitle() function to add the title to the chart by Chart_Title var 
    ggtitle(Chart_Title) + 
    # Set the theme of the visual from ggthemes package:
    theme_few()
  p
  
} else{
  
  plot.new()
  title("Input data not support Visualization.") 
}  


#  Structure to  develop R  visual in Power Bi 
# =============================================
# Make sure it meets the requirements for the desired R visual. 
# If not create  a blank plot with a message.

# if (<"Check data ">) {
#< R Code for R Visual>
# } else {
# plot.new()
# title(main = "Input data not support Visualization.)
# 

