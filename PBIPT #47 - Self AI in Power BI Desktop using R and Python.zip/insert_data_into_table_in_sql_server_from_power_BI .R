library(tidyverse)
library(RODBC)
# https://cran.r-project.org/web/packages/RODBC/RODBC.pdf
library(lubridate)

# Example : logging to monitor the amount of data being loaded into the data mart.


# Create a DSN with ODBC  to the SQL Server database


# In SSMS : 
#use[AdventureWorksDW2017];
#DROP TABLE IF EXISTS dbo.[etl_Log]; 
#CREATE TABLE dbo.[etl_Log] (
#  load_date DATETIME  DEFAULT (getdate()),
#  table_name VARCHAR(25),
#  num_of_records INT
#)

#select * from dbo.[etl_Log];
#
#
#
# Note : you cannot use  DEFAULT (getdate() becuase you will get : 
#error in odbcUpdate(channel, query, mydata, coldata[m, ], test = test,  : 
#missing columns in 'data
#DROP TABLE IF EXISTS dbo.[etl_Log]; 
#CREATE TABLE dbo.[etl_Log] (
#  load_date DATETIME  DEFAULT (getdate()),
#  table_name VARCHAR(25),
#  num_of_records INT
#)

table_name <- "DimAccount"
sql_query <- paste0(
  "SELECT * FROM dbo.",
  table_name)

conn <- odbcConnect(dsn = "SQL2017",uid = "sa", pwd = "Aa123456!")
read_df <- sqlQuery(channel = conn, query = sql_query)

# For large tables you will get following errors : 
#> df_read <- sqlQuery(channel = conn, query = sql)
# Error in odbcQuery(channel, query, rows_at_time) : 
#  'Calloc' could not allocate memory (214748364800 of 1 bytes)


# Arguments
#   dsn  character string. A registered data source name.
#   uid, pwd UID and password for authentication (if required).
#   connection character string. See your ODBC documentation for the format.
#   channel RODBC connection object returned by odbcConnect.

current_date <- now()
num_of_records <- nrow(read_df)
# num_of_records

# convert to list 
record_insert <- list(
  "load_date" = current_date, 
  "table_name" = table_name, 
  "num_of_records" = num_of_records)

# https://www.rdocumentation.org/packages/tibble/versions/3.0.6/topics/as_tibble
# as_tibble() turns an existing object, such as a data frame or matrix, 
# into a so-called tibble, a data frame with class tbl_df
record_insert <- as_tibble(record_insert)

sqlSave(
  channel = conn, 
  dat = record_insert, 
  tablename = "etl_Log", 
  append = TRUE, 
  rownames=FALSE)

odbcClose(conn)
# If you do not close odbc you will get : 
#> df_read <- sqlQuery(channel = conn, query = sql)
#warning messages from top-level task callback '1'
# message:
#  closing unused RODBC handle 17 


# select * from dbo.[etl_Log];
# 2021-02-18 12:43:15.000	DimAccount	99
# 2021-02-18 12:43:29.000	DimAccount	99

