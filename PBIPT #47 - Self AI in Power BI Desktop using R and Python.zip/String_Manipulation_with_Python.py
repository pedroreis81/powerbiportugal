# Processing strings and pattern matching with R &Python  
# =======================================================
# Power Query supports Basic string processing and pattern matching 
# Great for simple manipulation .
# R and Python enable advanced string manipulation and pattern
# unlike Power Query.

# Mask sensitive data using Python in Power BI
# mask the ID  and Phone Numbers Ex : for Microsoft Cognitive Services 


# Pandas is  data analytics component and an integral part of the SciPy
# ecosystem. 
# Includes very versatile data structures and routines to manage them. 
# Has capability to visualize data

# install it on the computer from cmd  
# C:\Python\Python39\Scripts\pip3.9.exe  install pandas
import pandas as pd

# re :  Regular expression operations: https://docs.python.org/3/library/re.html
import re

# os � Miscellaneous operating system interfaces
# https://docs.python.org/3/library/os.html
import os

def mask_text (clear_text):
    phone_pattern = \
         r"([0-9]{10})"
        #   r"([2-9][0-9]{2})[- .]([0-9]{3})[- .]([0-9]{4})"
    ID_pattern = r"\d{9}"
#ID_pattern = r"\d{3}-\d{2}-\d{4}"

# .sub(pattern, repl, string)
# Return the string obtained by replacing the leftmost 
# non-overlapping occurrences of pattern in string by the replacement repl. 
    cleanned_text = re.sub(
        phone_pattern, "XXXXXXXXXXX", clear_text)
    cleanned_text = re.sub(
        ID_pattern, "XXXXXXXXXX", cleanned_text)
    #ID_pattern, "XXX-XX-XXXX", cleanned_text)
    return cleanned_text

os.chdir("E:\String_Manipulation_with_Python")

# Read data stored in a comma-separated value (CSV) format
# with the method read_csv(). 
#  CSV file can be  at a remote URL or the disk
df = pd.read_csv("Customers_feedback.csv")
print(df)
#display the top five records:
df.head()
df.Remarks = df.Remarks.apply(mask_text)
df

